package com.fukuiteams.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * ブローウィンズのホームゲームの「試合情報」ページ(公式サイト /lp/game_...)から、
 * GitHub Actions(scripts/build_game_lp.py)が読み取った開場時刻・当日スケジュール・イベント。
 * data/game_lp.json に試合IDごとに入っている。
 */
private const val GAME_LP_JSON_URL =
    "https://raw.githubusercontent.com/masashi19790226-cloud/FukuiTeamsApp/main/data/game_lp.json"

data class LpTimelineItem(val time: String, val text: String)
data class LpEvent(val title: String, val text: String)

data class GameLp(
    /** 公式の試合情報ページのURL */
    val url: String,
    /** 開場時刻(例 13:40)。分からなければ空 */
    val openTime: String,
    val timeline: List<LpTimelineItem>,
    val events: List<LpEvent>
)

/**
 * 一面・試合詳細に出す開場時刻。
 * 当日のスケジュールに「シルバー会員先行入場開始」の行があればその時刻を、無ければ一般の開場時刻(チケット欄)を使う。
 * どちらも無ければ null。
 */
val GameLp.openLabel: String?
    get() {
        val silver = timeline.firstOrNull { it.text.contains("シルバー") && it.text.contains("入場") && it.time.isNotBlank() }
        return when {
            silver != null -> "開場 ${silver.time}(シルバー会員)"
            openTime.isNotBlank() -> "開場 $openTime"
            else -> null
        }
    }

/** 天気予報に使う入場の時刻(シルバー会員の先行入場、無ければ一般の開場)。「13:00」の形。分からなければ null */
val GameLp.entryTime: String?
    get() = timeline.firstOrNull { it.text.contains("シルバー") && it.text.contains("入場") && it.time.isNotBlank() }?.time
        ?: openTime.takeIf { it.isNotBlank() }

object GameLpRepository {
    /** いちばん最近読み込んだデータ(試合ID → 試合情報)。一面と試合詳細で共通に使う。 */
    var latest by mutableStateOf<Map<String, GameLp>>(emptyMap())
        private set

    suspend fun fetch(): Map<String, GameLp> = withContext(Dispatchers.IO) {
        try {
            val connection = URL(GAME_LP_JSON_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 10_000
            connection.readTimeout = 10_000
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val root = JSONObject(text)
            val map = mutableMapOf<String, GameLp>()
            root.keys().forEach { gameId ->
                val o = root.optJSONObject(gameId) ?: return@forEach
                val url = o.optString("url")
                if (url.isBlank()) return@forEach
                val tl = o.optJSONArray("timeline")
                val ev = o.optJSONArray("events")
                map[gameId] = GameLp(
                    url = url,
                    openTime = o.optString("open"),
                    timeline = (0 until (tl?.length() ?: 0)).mapNotNull { i ->
                        tl?.optJSONObject(i)?.let { LpTimelineItem(it.optString("time"), it.optString("text")) }
                    },
                    events = (0 until (ev?.length() ?: 0)).mapNotNull { i ->
                        ev?.optJSONObject(i)?.let { LpEvent(it.optString("title"), it.optString("text")) }
                    }
                )
            }
            latest = map
            map
        } catch (e: Exception) {
            // まだファイルが無い・通信できないときは、前回の内容のまま
            latest
        }
    }
}
